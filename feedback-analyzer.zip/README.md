# Feedback Analyzer – GCP Cloud Run + Firestore + NLP

## Overview
This is a sentiment analysis app where users submit feedback, and the app analyzes its sentiment using Google Cloud Natural Language API. All data is stored in Firestore.

## Features
- 🌐 Flask frontend with simple form
- 📊 Sentiment Analysis using Natural Language API
- 🔥 Firestore for storing feedback & sentiment
- 🐳 Dockerized for Cloud Run

## How to Deploy (GCP UI)
1. Go to [Cloud Run Console](https://console.cloud.google.com/run)
2. Click **Create Service**
3. Choose **Deploy from Source** → Upload this ZIP
4. Set Runtime to Python 3.11, Entrypoint to `python app.py`
5. Enable unauthenticated access
6. Done!

## Tech Stack
- Flask
- Firestore
- Google NLP API
- Cloud Run (free-tier compatible)